""" File for full (production) data

These songs will be called on integration and production server at the
installation.
"""

import anthem


@anthem.log
def main(ctx):
    """ Loading full data """
    # nothing yet
    return
