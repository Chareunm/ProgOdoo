{
    "name": "Gestion des étudiants",
    "version": "0.7",
    "category": "Generic Modules/Others",
    "description": """Test création module gestion des étudiants Odoo v14""",
    "author": "ROLLAND Noé",
    "depends": ["base"],
    "installable": True,
    "auto_install": False,
    "data": ["views/students_views.xml","views/training_views.xml","views/menu_views.xml"]
}